"""
Main Trading Engine

Orchestrates the execution of trading strategies, manages risk,
and provides the main event loop for the bot.
"""

import time
from typing import Dict, List, Optional
from datetime import datetime
from loguru import logger
import sys

from src.api.kalshi_connector import create_connector_from_env
from src.strategies.flb_harvester import FLBHarvester, FLBConfig


class TradingEngine:
    """
    Main trading engine that coordinates all strategies.
    """
    
    def __init__(self, dry_run: bool = True, use_demo: bool = True):
        """
        Initialize the trading engine.
        
        Args:
            dry_run: If True, log trades but don't execute
            use_demo: If True, use Kalshi demo environment
        """
        self.dry_run = dry_run
        self.use_demo = use_demo
        
        # Initialize API connector
        logger.info("Initializing Kalshi API connector...")
        self.api = create_connector_from_env()
        
        # Initialize strategies
        logger.info("Initializing trading strategies...")
        self.flb_strategy = FLBHarvester(
            api_connector=self.api,
            config=FLBConfig()
        )
        
        # Trading state
        self.is_running = False
        self.cycle_count = 0
        self.start_time = None
        
        # Performance tracking
        self.trades_executed = []
        self.errors = []
        
        logger.success("Trading engine initialized")
        logger.info(f"Mode: {'DRY RUN' if dry_run else 'LIVE'}")
        logger.info(f"Environment: {'DEMO' if use_demo else 'PRODUCTION'}")
    
    def start(self, scan_interval: int = 300):
        """
        Start the main trading loop.
        
        Args:
            scan_interval: Seconds between market scans (default: 5 minutes)
        """
        self.is_running = True
        self.start_time = datetime.now()
        
        logger.info("=" * 60)
        logger.info("STARTING TRADING ENGINE")
        logger.info("=" * 60)
        
        # Initial balance check
        self._check_balance()
        
        try:
            while self.is_running:
                self.cycle_count += 1
                cycle_start = time.time()
                
                logger.info(f"\n{'=' * 60}")
                logger.info(f"CYCLE #{self.cycle_count} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                logger.info(f"{'=' * 60}\n")
                
                # Run Strategy A: FLB Harvester
                try:
                    logger.info("Running Strategy A: FLB Harvester")
                    trades = self.flb_strategy.scan_and_trade(dry_run=self.dry_run)
                    self.trades_executed.extend(trades)
                    
                    # Show stats
                    stats = self.flb_strategy.get_stats()
                    logger.info(f"FLB Stats: {stats}")
                    
                except Exception as e:
                    logger.error(f"Error in FLB strategy: {e}")
                    self.errors.append({
                        'time': datetime.now(),
                        'strategy': 'FLB',
                        'error': str(e)
                    })
                
                # TODO: Add Strategy B (Alpha Specialist) here when implemented
                
                # Calculate cycle duration
                cycle_duration = time.time() - cycle_start
                logger.info(f"\nCycle completed in {cycle_duration:.2f}s")
                
                # Show summary
                self._print_summary()
                
                # Sleep until next scan
                sleep_time = max(0, scan_interval - cycle_duration)
                if sleep_time > 0:
                    logger.info(f"Sleeping for {sleep_time:.0f}s until next scan...\n")
                    time.sleep(sleep_time)
                
        except KeyboardInterrupt:
            logger.info("\nReceived shutdown signal...")
            self.stop()
        except Exception as e:
            logger.error(f"Fatal error in trading engine: {e}")
            self.stop()
    
    def stop(self):
        """Stop the trading engine gracefully."""
        self.is_running = False
        
        logger.info("\n" + "=" * 60)
        logger.info("SHUTTING DOWN TRADING ENGINE")
        logger.info("=" * 60)
        
        # Final summary
        self._print_final_summary()
        
        logger.info("Shutdown complete")
    
    def _check_balance(self):
        """Check and log account balance."""
        try:
            balance = self.api.get_balance()
            available = balance.get('balance', 0) / 100.0
            
            logger.info(f"Account balance: ${available:.2f}")
            
            if available < 100:
                logger.warning("Low balance! Consider adding funds.")
                
        except Exception as e:
            logger.error(f"Could not check balance: {e}")
    
    def _print_summary(self):
        """Print cycle summary statistics."""
        logger.info("\n--- Cycle Summary ---")
        logger.info(f"Total trades executed: {len(self.trades_executed)}")
        logger.info(f"Total errors: {len(self.errors)}")
        
        # Calculate total exposure
        if not self.dry_run:
            try:
                positions = self.api.get_positions()
                total_exposure = sum(abs(p.get('total_cost', 0)) for p in positions) / 100.0
                logger.info(f"Total exposure: ${total_exposure:.2f}")
            except:
                pass
    
    def _print_final_summary(self):
        """Print final summary before shutdown."""
        runtime = (datetime.now() - self.start_time).total_seconds() if self.start_time else 0
        
        logger.info("\n--- Final Summary ---")
        logger.info(f"Total runtime: {runtime/3600:.2f} hours")
        logger.info(f"Total cycles: {self.cycle_count}")
        logger.info(f"Total trades: {len(self.trades_executed)}")
        logger.info(f"Total errors: {len(self.errors)}")
        
        if self.errors:
            logger.warning(f"\nErrors encountered:")
            for err in self.errors[-5:]:  # Show last 5 errors
                logger.warning(f"  [{err['time']}] {err['strategy']}: {err['error']}")
        
        # Try to get final balance
        try:
            balance = self.api.get_balance()
            final_balance = balance.get('balance', 0) / 100.0
            logger.info(f"\nFinal balance: ${final_balance:.2f}")
        except:
            pass


def main():
    """Main entry point for the trading bot."""
    import argparse
    
    # Configure logging
    logger.remove()
    logger.add(
        sys.stderr,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
        level="INFO"
    )
    logger.add(
        "logs/trading_{time:YYYY-MM-DD}.log",
        rotation="1 day",
        retention="30 days",
        level="DEBUG"
    )
    
    # Parse arguments
    parser = argparse.ArgumentParser(description="Kalshi ML Trading Bot")
    parser.add_argument(
        "--live",
        action="store_true",
        help="Run in LIVE mode (executes real trades)"
    )
    parser.add_argument(
        "--demo",
        action="store_true",
        default=True,
        help="Use demo environment (default: True)"
    )
    parser.add_argument(
        "--interval",
        type=int,
        default=300,
        help="Scan interval in seconds (default: 300)"
    )
    
    args = parser.parse_args()
    
    # Safety check
    if not args.live:
        logger.warning("Running in DRY RUN mode - no trades will be executed")
        logger.warning("Use --live flag to execute real trades")
        dry_run = True
    else:
        logger.warning("=" * 60)
        logger.warning("LIVE MODE ENABLED - REAL TRADES WILL BE EXECUTED")
        logger.warning("=" * 60)
        response = input("Are you sure you want to continue? (yes/no): ")
        if response.lower() != "yes":
            logger.info("Aborted by user")
            return
        dry_run = False
    
    # Create and start engine
    engine = TradingEngine(
        dry_run=dry_run,
        use_demo=args.demo
    )
    
    engine.start(scan_interval=args.interval)


if __name__ == "__main__":
    main()
