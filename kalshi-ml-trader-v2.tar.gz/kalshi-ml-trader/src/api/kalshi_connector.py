"""
Kalshi API Connector

This module provides a clean interface to the Kalshi API, handling:
- Authentication
- Market data retrieval
- Order placement
- Position tracking
- Error handling and rate limiting

Based on the official Kalshi starter code with enhanced features.
"""

import os
import time
import requests
from typing import Dict, List, Optional, Any
from datetime import datetime
from loguru import logger


class KalshiAPIConnector:
    """
    Main connector class for interacting with Kalshi's API.
    
    Supports both demo and production environments with automatic
    token refresh and comprehensive error handling.
    """
    
    # API Base URLs
    DEMO_BASE_URL = "https://demo-api.kalshi.co/trade-api/v2"
    PROD_BASE_URL = "https://trading-api.kalshi.com/trade-api/v2"
    
    def __init__(self, email: str, password: str, use_demo: bool = True):
        """
        Initialize the Kalshi API connector.
        
        Args:
            email: Kalshi account email
            password: Kalshi account password
            use_demo: If True, use demo environment (default: True)
        """
        self.email = email
        self.password = password
        self.use_demo = use_demo
        self.base_url = self.DEMO_BASE_URL if use_demo else self.PROD_BASE_URL
        
        self.token: Optional[str] = None
        self.token_expiry: Optional[datetime] = None
        self.member_id: Optional[str] = None
        
        # Rate limiting
        self.last_request_time = 0
        self.min_request_interval = 0.1  # 100ms between requests
        
        logger.info(f"Initialized Kalshi API connector (demo={use_demo})")
        
    def _ensure_authenticated(self):
        """Ensure we have a valid authentication token."""
        if self.token is None or self._token_expired():
            self._authenticate()
    
    def _token_expired(self) -> bool:
        """Check if the current token has expired."""
        if self.token_expiry is None:
            return True
        # Add 5 minute buffer before actual expiry
        return datetime.now() >= self.token_expiry
    
    def _authenticate(self):
        """
        Authenticate with Kalshi API and store the token.
        
        Raises:
            Exception: If authentication fails
        """
        logger.info("Authenticating with Kalshi API...")
        
        endpoint = f"{self.base_url}/login"
        payload = {
            "email": self.email,
            "password": self.password
        }
        
        try:
            response = requests.post(endpoint, json=payload)
            response.raise_for_status()
            
            data = response.json()
            self.token = data["token"]
            self.member_id = data["member_id"]
            
            # Tokens typically last 24 hours
            from datetime import timedelta
            self.token_expiry = datetime.now() + timedelta(hours=23)
            
            logger.success("Successfully authenticated with Kalshi")
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Authentication failed: {e}")
            raise
    
    def _rate_limit(self):
        """Implement simple rate limiting."""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.min_request_interval:
            time.sleep(self.min_request_interval - elapsed)
        self.last_request_time = time.time()
    
    def _make_request(
        self, 
        method: str, 
        endpoint: str, 
        params: Optional[Dict] = None,
        json: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Make an authenticated API request with error handling.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            params: Query parameters
            json: JSON body
            
        Returns:
            Response data as dictionary
        """
        self._ensure_authenticated()
        self._rate_limit()
        
        url = f"{self.base_url}{endpoint}"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                json=json
            )
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {method} {endpoint} - {e}")
            raise
    
    # ========== Market Data Methods ==========
    
    def get_markets(
        self, 
        limit: int = 100,
        status: str = "open",
        series_ticker: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get list of markets.
        
        Args:
            limit: Maximum number of markets to return
            status: Market status filter (open, closed, settled)
            series_ticker: Filter by series ticker
            
        Returns:
            List of market dictionaries
        """
        params = {
            "limit": limit,
            "status": status
        }
        if series_ticker:
            params["series_ticker"] = series_ticker
        
        response = self._make_request("GET", "/markets", params=params)
        return response.get("markets", [])
    
    def get_market(self, ticker: str) -> Dict[str, Any]:
        """
        Get detailed information for a specific market.
        
        Args:
            ticker: Market ticker symbol
            
        Returns:
            Market details dictionary
        """
        response = self._make_request("GET", f"/markets/{ticker}")
        return response.get("market", {})
    
    def get_orderbook(self, ticker: str) -> Dict[str, Any]:
        """
        Get current orderbook for a market.
        
        Args:
            ticker: Market ticker symbol
            
        Returns:
            Orderbook with bids and asks
        """
        response = self._make_request("GET", f"/markets/{ticker}/orderbook")
        return response
    
    def get_trades(self, ticker: str, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get recent trades for a market.
        
        Args:
            ticker: Market ticker symbol
            limit: Maximum number of trades to return
            
        Returns:
            List of trade dictionaries
        """
        params = {"limit": limit}
        response = self._make_request("GET", f"/markets/{ticker}/trades", params=params)
        return response.get("trades", [])
    
    # ========== Trading Methods ==========
    
    def create_order(
        self,
        ticker: str,
        side: str,
        action: str,
        count: int,
        type: str = "market",
        yes_price: Optional[int] = None,
        no_price: Optional[int] = None,
        expiration_ts: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Create a new order.
        
        Args:
            ticker: Market ticker
            side: 'yes' or 'no'
            action: 'buy' or 'sell'
            count: Number of contracts
            type: Order type ('market' or 'limit')
            yes_price: Limit price for YES (in cents)
            no_price: Limit price for NO (in cents)
            expiration_ts: Order expiration timestamp
            
        Returns:
            Order confirmation dictionary
        """
        payload = {
            "ticker": ticker,
            "client_order_id": f"{ticker}_{int(time.time())}",
            "side": side,
            "action": action,
            "count": count,
            "type": type
        }
        
        if type == "limit":
            if yes_price is not None:
                payload["yes_price"] = yes_price
            if no_price is not None:
                payload["no_price"] = no_price
        
        if expiration_ts:
            payload["expiration_ts"] = expiration_ts
        
        logger.info(f"Creating order: {action} {count} {side} @ {ticker}")
        response = self._make_request("POST", "/portfolio/orders", json=payload)
        return response
    
    def cancel_order(self, order_id: str) -> Dict[str, Any]:
        """
        Cancel an existing order.
        
        Args:
            order_id: ID of order to cancel
            
        Returns:
            Cancellation confirmation
        """
        logger.info(f"Cancelling order: {order_id}")
        response = self._make_request("DELETE", f"/portfolio/orders/{order_id}")
        return response
    
    def get_orders(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get user's orders.
        
        Args:
            status: Filter by status (resting, canceled, executed)
            
        Returns:
            List of order dictionaries
        """
        params = {}
        if status:
            params["status"] = status
        
        response = self._make_request("GET", "/portfolio/orders", params=params)
        return response.get("orders", [])
    
    # ========== Portfolio Methods ==========
    
    def get_balance(self) -> Dict[str, Any]:
        """
        Get account balance information.
        
        Returns:
            Balance dictionary with available funds
        """
        response = self._make_request("GET", "/portfolio/balance")
        return response
    
    def get_positions(self) -> List[Dict[str, Any]]:
        """
        Get current positions.
        
        Returns:
            List of position dictionaries
        """
        response = self._make_request("GET", "/portfolio/positions")
        return response.get("positions", [])
    
    def get_fills(self, ticker: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get trade fills.
        
        Args:
            ticker: Optional ticker filter
            
        Returns:
            List of fill dictionaries
        """
        params = {}
        if ticker:
            params["ticker"] = ticker
        
        response = self._make_request("GET", "/portfolio/fills", params=params)
        return response.get("fills", [])
    
    # ========== Utility Methods ==========
    
    def get_best_price(self, ticker: str, side: str) -> Optional[int]:
        """
        Get the best available price for a side.
        
        Args:
            ticker: Market ticker
            side: 'yes' or 'no'
            
        Returns:
            Best price in cents, or None if no orders
        """
        orderbook = self.get_orderbook(ticker)
        
        if side == "yes":
            asks = orderbook.get("yes", [])
            if asks:
                return asks[0][0]  # Best ask price
        else:
            bids = orderbook.get("no", [])
            if bids:
                return bids[0][0]  # Best bid price
        
        return None
    
    def get_market_probability(self, ticker: str) -> float:
        """
        Get the market's implied probability.
        
        Args:
            ticker: Market ticker
            
        Returns:
            Probability as decimal (0.0 to 1.0)
        """
        market = self.get_market(ticker)
        yes_price = market.get("yes_bid", 50)  # Default to 50 if not available
        return yes_price / 100.0


# ========== Factory Function ==========

def create_connector_from_env() -> KalshiAPIConnector:
    """
    Create a Kalshi connector using environment variables.
    
    Expected environment variables:
        KALSHI_EMAIL: Account email
        KALSHI_PASSWORD: Account password
        KALSHI_USE_DEMO: 'true' or 'false' (default: true)
    
    Returns:
        Configured KalshiAPIConnector instance
    """
    from dotenv import load_dotenv
    load_dotenv()
    
    email = os.getenv("KALSHI_EMAIL")
    password = os.getenv("KALSHI_PASSWORD")
    use_demo = os.getenv("KALSHI_USE_DEMO", "true").lower() == "true"
    
    if not email or not password:
        raise ValueError("KALSHI_EMAIL and KALSHI_PASSWORD must be set in environment")
    
    return KalshiAPIConnector(email, password, use_demo)
