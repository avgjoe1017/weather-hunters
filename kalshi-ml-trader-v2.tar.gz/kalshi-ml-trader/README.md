# Kalshi ML Trading Program: "Alpha & Bias"

A hybrid machine learning trading system that exploits documented inefficiencies in Kalshi prediction markets through a dual-strategy approach.

## Project Overview

This trading bot combines two proven strategies:

1. **Strategy A: FLB Harvester** - Exploits the Favorite-Longshot Bias (structural market inefficiency)
2. **Strategy B: Alpha Specialist** - Generates superior probability predictions using specialized ML models

## Key Advantages Over Existing Bots

- ✅ **100% Backtestable** - No black-box LLMs
- ✅ **Data-driven** - Built on academic research and statistical proof
- ✅ **Feature-based ML** - Transparent, debuggable models
- ✅ **Dual-edge approach** - Structural + informational advantages

## Project Structure

```
kalshi-ml-trader/
├── src/
│   ├── api/              # Kalshi API connector
│   ├── strategies/       # Strategy A (FLB) & Strategy B (Alpha)
│   ├── models/           # ML models
│   ├── features/         # Feature pipeline for data gathering
│   ├── backtest/         # Custom backtesting engine
│   └── trading/          # Main trading logic engine
├── data/                 # Historical data and features
├── models/               # Trained model artifacts
├── config/               # Configuration files
├── notebooks/            # Analysis and development notebooks
└── tests/                # Unit tests

```

## Setup Instructions

### 1. Environment Setup

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. API Configuration

Create a `.env` file:
```
KALSHI_EMAIL=your_email@example.com
KALSHI_PASSWORD=your_password
KALSHI_USE_DEMO=true  # Start with demo mode
```

### 3. Running the Bot

```bash
# Dry run (no real trades)
python src/main.py --dry-run

# Live trading (demo environment)
python src/main.py --demo

# Live trading (real money - use with caution)
python src/main.py --live
```

## Strategy Details

### Strategy A: FLB Harvester
- Scans all markets 24/7
- Buys favorites (price ≥ 90¢)
- Sells longshots (price ≤ 10¢)
- Based on "Makers and Takers" whitepaper

### Strategy B: Alpha Specialist
- Focuses on weather markets initially
- Aggregates multiple forecasting models
- Generates superior probability estimates
- Trades when edge > minimum threshold

## Development Roadmap

- [x] Project architecture design
- [ ] Phase 1: API connector & basic framework
- [ ] Phase 2: Strategy A (FLB) implementation
- [ ] Phase 3: Feature pipeline for weather data
- [ ] Phase 4: Strategy B (Alpha) ML model
- [ ] Phase 5: Backtesting framework
- [ ] Phase 6: Hybrid model integration
- [ ] Phase 7: Live testing & optimization

## Safety Features

- Dry run mode for testing
- Demo environment support
- Position size limits
- Risk management controls
- Comprehensive logging

## References

- "Makers and Takers: The Economics of the Kalshi Prediction Market" (Whelan, et al.)
- "Markets vs. Machines" (DiVA Portal)

## License

MIT License - See LICENSE file for details
